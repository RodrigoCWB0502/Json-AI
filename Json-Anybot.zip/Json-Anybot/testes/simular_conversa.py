# -*- coding: utf-8 -*-
"""
Mostra como a conversa FICA para o contribuinte, usando as mensagens
escritas no proprio Main.Json. Serve para ler o atendimento em voz alta
e sentir se soa como gente ou como formulario.

Uso: python testes/simular_conversa.py
"""

import sys
from roteador import MAIN, SPEC, rotear

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

INTENCOES = {i["id"]: i for i in SPEC["intencoes"]}
TRANSVERSAIS = {t["id"]: t for t in SPEC["intencoesTransversais"]["itens"]}
ASSUNTOS = {a["assunto"]: a for a in SPEC["assuntosAmbiguos"]["itens"]}
ACOES = {a["id"]: a for a in MAIN["acoes"]}


SEGURANCA = {r["id"]: r for r in SPEC["regrasDeSeguranca"]["regras"]}


def _executa(intencao_id):
    i = INTENCOES[intencao_id]
    return (f'{i["confirmacaoImplicita"]}\n'
            f'   [chama {ACOES[i["acaoDestino"]]["endpoint"]["url"]}]')


def responder(texto, contexto=None, tentativas=0):
    """Traduz a decisao do roteador na fala do bot.
    Devolve (fala, resultado, pergunta_pendente)."""
    r = rotear(texto, contexto)
    d, destino = r["decisao"], r["destino"]

    if d == "RECUSA_SEGURANCA":
        return SEGURANCA[destino.split(":", 1)[1]]["resposta"], r, None

    if d == "TRANSVERSAL":
        return TRANSVERSAIS[destino.split(":", 1)[1]]["resposta"], r, None

    if d in ("ROTEAR_DIRETO", "RESPOSTA_A_PERGUNTA"):
        return _executa(destino), r, None

    if d == "ROTEAR_COM_CONFIRMACAO":
        i = INTENCOES[destino]
        return f'Acho que você quer: {i["rotuloCurto"]}. É isso mesmo?', r, None

    if d == "DESAMBIGUAR_POR_ASSUNTO":
        a = ASSUNTOS[destino.split(":", 1)[1]]
        pendente = [{"id": o["intencao"], "rotulo": o["rotulo"]} for o in a["opcoes"]]
        opcoes = "\n".join(f'   {n}. {o["rotulo"]}' for n, o in enumerate(a["opcoes"], 1))
        return f'{a["pergunta"]}\n{opcoes}', r, pendente

    if d == "DESAMBIGUAR":
        pendente = [{"id": i, "rotulo": INTENCOES[i]["rotuloCurto"]} for i in r["opcoes"]]
        opcoes = "\n".join(f'   {n}. {p["rotulo"]}' for n, p in enumerate(pendente, 1))
        return f'Só pra eu não errar — você quer:\n{opcoes}', r, pendente

    escal = SPEC["fallback"]["escalonamento"]
    return escal[min(tentativas, len(escal) - 1)]["mensagem"], r, None


def interativo():
    """Modo demonstração: a pessoa digita, o bot responde, e os bastidores
    da decisão aparecem embaixo. Mantém o contexto entre as mensagens."""
    print("\n" + "=" * 70)
    print("ATENDIMENTO VIRTUAL — PREFEITURA DE SANTA RITA DO CONTORNO")
    print("=" * 70)
    print(MAIN["identificacaoUsuario"]["mensagens"]["identificado"]
          .replace("{{nomeExibicao}}", "CORDIOLINO"))
    print("\n(digite 'sair' para encerrar)\n")

    contexto = {"documentoRFB": "60072334568"}
    tentativas = 0

    while True:
        try:
            fala = input("Você: ").strip()
        except (EOFError, KeyboardInterrupt):
            break
        if not fala:
            continue
        if fala.lower() in ("sair", "exit", "quit"):
            break

        resposta, r, pendente = responder(fala, contexto, tentativas)
        print(f"\nBot: {resposta}\n")
        print(f"     └─ {r['decisao']}"
              + (f" · placar {r['ranking'][:3]}" if r.get("ranking") else "")
              + f"\n        texto normalizado: \"{r['normalizado']}\"\n")

        contexto["perguntaPendente"] = pendente
        tentativas = tentativas + 1 if r["decisao"] == "FALLBACK" else 0

    print("\n" + MAIN["fluxoAtendimento"]["etapas"][6]["loop"]["mensagemEncerramento"] + "\n")


CENARIOS = [
    ("Rota direta, linguagem de balcão", ["quanto eu devo pra prefeitura"]),
    ("Erro de digitação + assunto", ["meu iptu ta atrazado"]),
    ("Assunto sem ação: o bot devolve o contexto que a pessoa deu", ["iptu"]),
    ("O bot lembra do que perguntou: a resposta é só '2'", ["iptu", "2"]),
    ("Mudou de ideia no meio da pergunta", ["iptu", "na verdade quero uma certidao"]),
    ("Dado de outra pessoa: recusa", ["quero a divida do meu vizinho o cpf dele e 123.456.789-00"]),
    ("Empate honesto entre duas ações", ["quero resolver meu iptu atrasado e ja pagar"]),
    ("O verbo é o mesmo, o objeto é que manda", ["preciso da segunda via do meu iptu",
                                                 "segunda via do alvara"]),
    ("Serviço que a Prefeitura tem, mas o bot ainda não", ["meu pai faleceu e o imovel ainda ta no nome dele"]),
    ("Assunto de outro órgão", ["preciso pagar o ipva"]),
    ("Escalonamento do fallback em 3 tentativas", ["preciso resolver isso hoje",
                                                   "voces atendem no sabado",
                                                   "aqui e a dona maria"]),
]


def main():
    if len(sys.argv) > 1 and sys.argv[1] in ("--interativo", "-i"):
        interativo()
        return

    contexto = {"documentoRFB": "60072334568"}
    for titulo, falas in CENARIOS:
        print("\n" + "=" * 70)
        print(titulo.upper())
        print("=" * 70)
        pendente, ctx = None, dict(contexto)
        for n, fala in enumerate(falas):
            ctx["perguntaPendente"] = pendente
            resposta, r, pendente = responder(fala, ctx, tentativas=n if len(falas) > 1 else 0)
            print(f"\n  Contribuinte: {fala}")
            print(f"  Bot: {resposta}")
            print(f"       ({r['decisao']}"
                  + (f" · placar {r['ranking'][:2]}" if r.get("ranking") else "") + ")")
    print()


if __name__ == "__main__":
    main()
