# -*- coding: utf-8 -*-
"""
Executa o Roteamento.Json como especificacao viva.

Nao e o codigo de producao do chatbot: e um simulador que implementa
literalmente as regras descritas em Roteamento.Json, para conseguirmos
medir se o vocabulario e os limiares escolhidos aguentam frases reais
antes de mandar o JSON para o treino da IA.

Uso:
    python testes/roteador.py                # corpus de calibragem
    python testes/roteador.py --validacao    # holdout (frases nunca usadas na calibragem)
    python testes/roteador.py "texto"        # explica a decisao para uma frase
"""

import json
import re
import sys
import unicodedata
from difflib import SequenceMatcher
from pathlib import Path

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

RAIZ = Path(__file__).resolve().parent.parent
MAIN = json.loads((RAIZ / "Main.Json").read_text(encoding="utf-8"))
SPEC = MAIN["roteamentoLinguagemNatural"]
NORM = SPEC["normalizacao"]
PONT = SPEC["modeloDePontuacao"]
PESOS = PONT["pesos"]
LIM = PONT["limiares"]
FUZZY = NORM["toleranciaErroDigitacao"]["limiarSimilaridade"]
TAM_MIN = NORM["toleranciaErroDigitacao"]["tamanhoMinimo"]
DIF_MAX = NORM["toleranciaErroDigitacao"]["diferencaMaximaDeTamanho"]
ERROS = NORM["errosComuns"]["trocas"]


# ---------------------------------------------------------------- normalizacao

def normalizar(texto):
    t = texto.lower()
    t = unicodedata.normalize("NFD", t)
    t = "".join(c for c in t if unicodedata.category(c) != "Mn")
    t = re.sub(r"[^a-z0-9]+", " ", t)
    t = re.sub(r"([a-z])\1{2,}", r"\1", t)      # kkkkkk -> k, naaaao -> nao
    #  ^ so letras: aplicado a digitos, isso destruia documento e valor
    #    ("0001" virava "01", quebrando a deteccao de CNPJ)
    t = re.sub(r"\s+", " ", t).strip()
    for tabela in (NORM["abreviacoes"], ERROS):
        for de, para in tabela.items():
            t = re.sub(r"(?<![a-z0-9])" + re.escape(de) + r"(?![a-z0-9])", para, t)
    return re.sub(r"\s+", " ", t).strip()


def tokenizar(texto_norm):
    """Devolve [(palavra, inicio, fim)] com as posicoes no texto normalizado."""
    return [(m.group(0), m.start(), m.end()) for m in re.finditer(r"[a-z0-9]+", texto_norm)]


def palavras_casam(palavra, alvo):
    if palavra == alvo:
        return True
    if min(len(palavra), len(alvo)) < TAM_MIN:
        return False
    if abs(len(palavra) - len(alvo)) > DIF_MAX:
        return False
    return SequenceMatcher(None, palavra, alvo).ratio() >= FUZZY


def achar_ocorrencias(tokens, termo):
    """Todos os trechos (inicio, fim) do texto que casam com o termo,
    palavra a palavra, tolerando erro de digitacao."""
    alvo = termo.split()
    n = len(alvo)
    achados = []
    for i in range(len(tokens) - n + 1):
        janela = tokens[i:i + n]
        if all(palavras_casam(janela[k][0], alvo[k]) for k in range(n)):
            achados.append((janela[0][1], janela[-1][2]))
    return achados


# ---------------------------------------------------------------- pontuacao

def coletar(tokens, termos, peso):
    return [(ini, fim, peso, t) for t in termos for (ini, fim) in achar_ocorrencias(tokens, t)]


def sobrepoe(a, b):
    return a[0] < b[1] and b[0] < a[1]


def pontuar_intencao(tokens, intencao):
    achados = (
        coletar(tokens, intencao.get("gatilhosFortes", []), PESOS["gatilhosFortes"])
        + coletar(tokens, intencao.get("gatilhosMedios", []), PESOS["gatilhosMedios"])
        + coletar(tokens, intencao.get("gatilhosFracos", []), PESOS["gatilhosFracos"])
    )
    # regraDeSobreposicao: no mesmo trecho, so conta o gatilho de maior peso
    achados.sort(key=lambda x: (-x[2], x[0] - x[1]))
    aceitos = []
    for a in achados:
        if not any(sobrepoe(a, b) for b in aceitos):
            aceitos.append(a)

    score = sum(a[2] for a in aceitos)
    antis = [t for t in intencao.get("antiGatilhos", []) if achar_ocorrencias(tokens, t)]
    score += len(antis) * PESOS["antiGatilhos"]
    return score, aceitos, antis


def spans_de_assunto(tokens):
    """Trechos ocupados por termos de assunto, com o assunto de cada um."""
    spans = []
    for item in SPEC["assuntosAmbiguos"]["itens"]:
        for termo in item["termos"]:
            for (ini, fim) in achar_ocorrencias(tokens, termo):
                spans.append((ini, fim, item, termo))
    return spans


def casar_transversal(tokens, ids):
    for item in SPEC["intencoesTransversais"]["itens"]:
        if item["id"] not in ids:
            continue
        for g in item["gatilhos"]:
            if achar_ocorrencias(tokens, g):
                return item
    return None


# ------------------------------------------------- continuidade e seguranca

ORDINAIS = {
    "primeiro": 1, "primeira": 1, "de cima": 1, "o de cima": 1,
    "segundo": 2, "segunda": 2, "terceiro": 3, "terceira": 3,
    "quarto": 4, "quarta": 4,
}
RECUSAS = ["nenhum", "nenhuma", "nenhuma dessas", "nenhum desses",
           "nao e isso", "outra coisa", "nada disso"]


def responder_pergunta_pendente(norm, tokens, opcoes):
    """continuidadeDaConversa.perguntaPendente: interpreta '1', 'a primeira',
    'boleto' ou 'nenhum' contra a lista que o bot acabou de oferecer.
    Devolve o id escolhido, 'RECUSA' ou None."""
    if any(achar_ocorrencias(tokens, r) for r in RECUSAS):
        return "RECUSA"

    m = re.search(r"(?<![a-z0-9])([1-9])(?![a-z0-9])", norm)
    if m and int(m.group(1)) <= len(opcoes):
        return opcoes[int(m.group(1)) - 1]["id"]

    for termo, pos in ORDINAIS.items():
        if achar_ocorrencias(tokens, termo) and pos <= len(opcoes):
            return opcoes[pos - 1]["id"]
    if achar_ocorrencias(tokens, "ultimo") or achar_ocorrencias(tokens, "ultima"):
        return opcoes[-1]["id"]

    # texto do rotulo: vence quem tiver mais palavras significativas em comum
    melhor, melhor_n = None, 0
    for o in opcoes:
        palavras = [p for p in normalizar(o["rotulo"]).split() if len(p) > 3]
        n = sum(1 for p in palavras if achar_ocorrencias(tokens, p))
        if n > melhor_n:
            melhor, melhor_n = o["id"], n
    return melhor


def documento_de_terceiro(norm, contexto):
    """regrasDeSeguranca.documento_de_terceiro."""
    da_sessao = (contexto or {}).get("documentoRFB")
    if not da_sessao:
        return False
    for m in re.finditer(r"\d[\d\s]{9,20}\d", norm):
        digitos = re.sub(r"\D", "", m.group(0))
        if len(digitos) in (11, 14) and digitos != re.sub(r"\D", "", da_sessao):
            return True
    return False


# ---------------------------------------------------------------- decisao

def rotear(texto, contexto=None):
    norm = normalizar(texto)
    tokens = tokenizar(norm)
    passo = {"texto": texto, "normalizado": norm, "ranking": []}

    # 0. seguranca: documento que nao e o da sessao
    if documento_de_terceiro(norm, contexto):
        return dict(passo, decisao="RECUSA_SEGURANCA",
                    destino="seg:documento_de_terceiro", score=None)

    # 1. resposta a uma pergunta que o bot acabou de fazer
    pendente = (contexto or {}).get("perguntaPendente")
    if pendente:
        escolha = responder_pergunta_pendente(norm, tokens, pendente)
        if escolha == "RECUSA":
            return dict(passo, decisao="FALLBACK", destino="fallback", score=None)
        if escolha:
            return dict(passo, decisao="RESPOSTA_A_PERGUNTA", destino=escolha, score=None)
        # se nao casou, segue o fluxo normal: pode ser assunto novo

    # 3. transversais de precedencia absoluta
    absolutas = SPEC["intencoesTransversais"]["precedenciaAbsoluta"]
    t = casar_transversal(tokens, absolutas)
    if t:
        return dict(passo, decisao="TRANSVERSAL", destino="trans:" + t["id"], score=None, ranking=[])

    # 4. pontuar intencoes de servico
    placar = []
    for intencao in SPEC["intencoes"]:
        score, aceitos, antis = pontuar_intencao(tokens, intencao)
        placar.append({"id": intencao["id"], "score": score, "aceitos": aceitos, "antis": antis})
    placar.sort(key=lambda x: -x["score"])
    passo["ranking"] = [(p["id"], p["score"]) for p in placar[:4]]
    topo, segundo = placar[0], placar[1]

    # 5. demais transversais (so vencem se nenhum servico atingiu o minimo)
    demais = [i["id"] for i in SPEC["intencoesTransversais"]["itens"] if i["id"] not in absolutas]
    if topo["score"] < LIM["confirmacaoMinima"]:
        t = casar_transversal(tokens, demais)
        if t:
            return dict(passo, decisao="TRANSVERSAL", destino="trans:" + t["id"], score=None)

    # 6. assunto sem acao
    assuntos = spans_de_assunto(tokens)
    if assuntos:
        casados = [a for p in placar for a in p["aceitos"]]
        tem_acao = any(
            not any(s[0] <= a[0] and a[1] <= s[1] for s in assuntos)
            for a in casados
        )
        if casados and not tem_acao:
            # prioridade: citado primeiro; em empate, termo mais longo
            vencedor = min(assuntos, key=lambda s: (s[0], -(s[1] - s[0])))[2]
            return dict(passo, decisao="DESAMBIGUAR_POR_ASSUNTO",
                        destino="amb:" + vencedor["assunto"], score=topo["score"])

    # 7. tabela de decisao
    margem = topo["score"] - segundo["score"]
    if topo["score"] >= LIM["aceiteDireto"] and margem >= LIM["margemSobreSegundo"]:
        return dict(passo, decisao="ROTEAR_DIRETO", destino=topo["id"], score=topo["score"])
    if topo["score"] >= LIM["confirmacaoMinima"] and margem >= LIM["margemSobreSegundo"]:
        return dict(passo, decisao="ROTEAR_COM_CONFIRMACAO", destino=topo["id"], score=topo["score"])
    if topo["score"] >= LIM["confirmacaoMinima"]:
        empatados = [p["id"] for p in placar
                     if topo["score"] - p["score"] < LIM["margemSobreSegundo"]][:4]
        return dict(passo, decisao="DESAMBIGUAR", destino="desambiguar",
                    opcoes=empatados, score=topo["score"])

    # 8. fallback
    return dict(passo, decisao="FALLBACK", destino="fallback", score=topo["score"])


# ---------------------------------------------------------------- testes

def montar_contexto(caso):
    """Reconstroi o estado da conversa descrito pelo caso de teste."""
    ctx = {}
    if caso.get("sessao"):
        ctx["documentoRFB"] = caso["sessao"]
    p = caso.get("perguntaDe")
    if isinstance(p, str) and p.startswith("amb:"):
        item = next(a for a in SPEC["assuntosAmbiguos"]["itens"]
                    if a["assunto"] == p.split(":", 1)[1])
        ctx["perguntaPendente"] = [{"id": o["intencao"], "rotulo": o["rotulo"]}
                                   for o in item["opcoes"]]
    elif isinstance(p, list):
        rot = {i["id"]: i["rotuloCurto"] for i in SPEC["intencoes"]}
        ctx["perguntaPendente"] = [{"id": i, "rotulo": rot[i]} for i in p]
    return ctx


def avaliar(caso, r):
    esp = caso["esperado"]
    d = r["decisao"]
    if esp == "desambiguar":
        return d == "DESAMBIGUAR" and all(i in r.get("opcoes", []) for i in caso["esperadoEntre"])
    if esp == "fallback":
        return d == "FALLBACK"
    if esp.startswith(("amb:", "trans:", "seg:")):
        return r["destino"] == esp
    aceitos = [esp] + caso.get("aceitaTambem", [])
    return (d in ("ROTEAR_DIRETO", "ROTEAR_COM_CONFIRMACAO", "RESPOSTA_A_PERGUNTA")
            and r["destino"] in aceitos)


def checar_integridade():
    """Toda intencao tem que apontar para uma acao que existe de verdade."""
    ids = {a["id"] for a in MAIN["acoes"]}
    erros = [i["id"] for i in SPEC["intencoes"] if i["acaoDestino"] not in ids]
    destinos = {o["intencao"] for it in SPEC["assuntosAmbiguos"]["itens"] for o in it["opcoes"]}
    erros += [d for d in destinos if d not in ids]
    if erros:
        print(f"!! INTEGRIDADE: destino inexistente em acoes[]: {erros}")
    else:
        print(f"Integridade OK: {len(SPEC['intencoes'])} intencoes -> {len(ids)} acoes existentes")
    return not erros


ROTAS = ("ROTEAR_DIRETO", "ROTEAR_COM_CONFIRMACAO", "RESPOSTA_A_PERGUNTA")
PERGUNTAS = ("DESAMBIGUAR", "DESAMBIGUAR_POR_ASSUNTO", "FALLBACK")


def severidade(caso, r):
    """Nem toda falha custa o mesmo. Levar a pessoa para o servico errado e
    grave; perguntar uma vez a mais so custa uma mensagem."""
    esperava_rota = not caso["esperado"].startswith(("amb:", "trans:", "seg:")) \
        and caso["esperado"] not in ("fallback", "desambiguar")
    if r["decisao"] in ROTAS and esperava_rota:
        return "GRAVE  (levou para o servico errado)"
    if r["decisao"] in ROTAS and not esperava_rota:
        return "GRAVE  (agiu quando devia ter perguntado)"
    if r["decisao"] in PERGUNTAS and esperava_rota:
        return "LEVE   (perguntou a mais, mas nao errou)"
    return "MEDIO  (resposta de tipo errado)"


ARQUIVOS = {
    "--validacao": "corpus_validacao.json",
    "--conversa": "corpus_conversa.json",
}


def main():
    checar_integridade()
    arquivo = "corpus.json"
    if len(sys.argv) > 1 and sys.argv[1] in ARQUIVOS:
        arquivo = ARQUIVOS[sys.argv[1]]
    elif len(sys.argv) > 1:
        r = rotear(" ".join(sys.argv[1:]))
        print(json.dumps(r, ensure_ascii=False, indent=2, default=str))
        return

    print(f"[{arquivo}]")
    corpus = json.loads((RAIZ / "testes" / arquivo).read_text(encoding="utf-8"))["casos"]
    falhas, por_cat = [], {}

    for caso in corpus:
        r = rotear(caso["texto"], montar_contexto(caso))
        ok = avaliar(caso, r)
        cat = por_cat.setdefault(caso["categoria"], [0, 0])
        cat[1] += 1
        if ok:
            cat[0] += 1
        else:
            falhas.append((caso, r))

    total = len(corpus)
    acertos = total - len(falhas)
    print("=" * 72)
    print(f"CORPUS: {total} frases | ACERTOS: {acertos} | FALHAS: {len(falhas)} "
          f"| {acertos / total * 100:.1f}%")
    print("=" * 72)
    print("\nPor categoria:")
    for cat in sorted(por_cat):
        a, t = por_cat[cat]
        marca = "OK " if a == t else "!! "
        print(f"  {marca}{cat:24s} {a:2d}/{t:2d}")

    if falhas:
        print(f"\n{'-' * 72}\nFALHAS ({len(falhas)}):\n")
        for caso, r in falhas:
            print(f'  "{caso["texto"]}"')
            print(f'     esperado : {caso["esperado"]}')
            print(f'     obtido   : {r["decisao"]} -> {r["destino"]}'
                  + (f' {r.get("opcoes")}' if r.get("opcoes") else ""))
            print(f'     placar   : {r["ranking"]}')
            print(f'     gravidade: {severidade(caso, r)}')
            print()

        graves = sum(1 for c, r in falhas if severidade(c, r).startswith("GRAVE"))
        print(f'  >> {graves} falha(s) GRAVE(s) e {len(falhas) - graves} '
              f'de baixo impacto.')
        print('     Falha grave = o contribuinte foi levado ao servico errado sem perceber.')
        print('     Falha leve  = o bot perguntou uma vez a mais. Custa uma mensagem, nao um erro.')

    # distribuicao das decisoes, para ver se o bot pergunta demais ou de menos
    dist = {}
    for caso in corpus:
        d = rotear(caso["texto"], montar_contexto(caso))["decisao"]
        dist[d] = dist.get(d, 0) + 1
    print("-" * 72)
    print("Distribuicao das decisoes:")
    for d in sorted(dist, key=lambda k: -dist[k]):
        print(f"  {d:26s} {dist[d]:3d}  ({dist[d] / total * 100:.0f}%)")

    return 0 if not falhas else 1


if __name__ == "__main__":
    sys.exit(main())
