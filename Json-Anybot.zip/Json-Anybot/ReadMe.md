# Json Anybot — WeTrib

Arquivo de treino do atendimento virtual tributário. O `Main.Json` descreve
tudo que a IA precisa saber: como identificar o contribuinte, como entender o
que ele quer, qual endpoint chamar e como responder.

Cenário de teste: **Santa Rita do Contorno**, município fictício de ~40 mil
habitantes, com público que não tem intimidade com chatbot.

---

## 1. O que mudou nesta versão

Antes o atendimento era um menu numerado. Agora o caminho principal é o
contribuinte **escrever com as próprias palavras** — "quanto eu devo", "perdi
meu carnê", "meu iptu tá atrazado" — e a IA resolver para o endpoint certo.

O menu não foi removido: virou rede de segurança. Ele aparece quando o bot não
entende duas vezes seguidas, ou quando a própria pessoa pede a lista.

Seção responsável: `roteamentoLinguagemNatural`, dentro do `Main.Json`.

---

## 2. Passo a passo: rodando pela primeira vez

Só precisa de Python 3 instalado. Não tem dependência externa, não tem
`pip install`, não precisa de internet.

### Passo 1 — abrir o terminal na pasta do projeto

```bash
cd C:/Users/Pichau/Downloads/ACL/ACL/Json-Anybot
```

### Passo 2 — conferir que o JSON está válido e íntegro

```bash
python testes/roteador.py --validacao
```

A primeira linha da saída tem que ser `Integridade OK: 9 intencoes -> 9 acoes
existentes`. Isso confirma que toda intenção aponta para uma ação que existe
de verdade em `acoes[]` — se alguém renomear um `id` e esquecer de atualizar o
outro lado, essa linha acusa.

### Passo 3 — rodar as três baterias de teste

```bash
python testes/roteador.py              # 87 frases de calibragem
python testes/roteador.py --validacao  # 43 frases nunca usadas na calibragem
python testes/roteador.py --conversa   # 19 casos de conversa e de segurança
```

### Passo 4 — ver o atendimento como o cidadão vê

```bash
python testes/simular_conversa.py
```

Imprime 11 diálogos completos, com a fala do bot montada a partir das mensagens
do próprio JSON.

### Passo 5 — testar uma frase qualquer

```bash
python testes/roteador.py "meu iptu ta atrazado"
```

Mostra o texto normalizado, o placar de cada intenção e a decisão tomada. É o
comando para usar quando alguém perguntar "e se a pessoa escrever assim?".

---

## 3. Passo a passo da demonstração ao vivo

```bash
python testes/simular_conversa.py --interativo
```

Abre o atendimento em modo conversa: você digita, o bot responde e os
bastidores da decisão aparecem embaixo de cada resposta. O contexto é mantido
entre as mensagens, então dá para responder "2" a uma pergunta do bot.

**Roteiro sugerido, em ordem** — cada frase mostra uma capacidade diferente:

| # | Digite | O que a plateia vê |
|---|---|---|
| 1 | `quanto eu devo pra prefeitura` | Linguagem de balcão vira chamada de endpoint, sem menu |
| 2 | `meu iptu ta atrazado` | Erro de digitação e abreviação não atrapalham |
| 3 | `iptu` | Assunto sem ação: o bot devolve o contexto que a pessoa deu, não o menu genérico |
| 4 | `2` | Ele lembra do que perguntou — a resposta pode ser só um número |
| 5 | `preciso da segunda via do meu iptu` | Vai para guia de recolhimento |
| 6 | `segunda via do alvara` | Mesmo verbo, objeto diferente, destino diferente |
| 7 | `meu pai faleceu e o imovel ainda ta no nome dele` | Serviço que ainda não existe: o bot admite em vez de fingir |
| 8 | `preciso pagar o ipva` | Tributo de outro órgão: recusa explicando |
| 9 | `quero a divida do meu vizinho o cpf dele e 123.456.789-00` | Recusa consulta de terceiro |
| 10 | `asdasdasd` | Fallback educado, com exemplos |

Se alguém da plateia quiser testar uma frase própria, deixe — é o melhor
momento da apresentação. Se o bot errar, o placar aparece na tela e dá para
explicar exatamente por quê.

---

## 4. Como a decisão é tomada

Cada intenção soma pontos conforme as palavras encontradas:

| Tipo de gatilho | Peso | Exemplo em "consulta de lançamentos" |
|---|---|---|
| Forte | +3 | `quanto eu devo`, `em aberto`, `nome sujo` |
| Médio | +2 | `atrasado`, `pendencia`, `inadimplente` |
| Fraco | +1 | `imposto`, `iptu`, `prefeitura` |
| Anti-gatilho | −4 | `parcelar`, `isencao`, `certidao` |

Com o placar montado, o bot decide:

- **Executa direto** se a primeira colocada tem 3+ pontos e está 2 à frente da segunda.
- **Confirma antes** se tem 2+ pontos e a mesma folga.
- **Pergunta entre as empatadas** se duas ficaram perto demais.
- **Pergunta sobre o assunto** se a pessoa citou o tema mas nenhuma ação ("iptu", "minha empresa").
- **Fallback em 3 degraus** se nada pontuou: reformular → mostrar o menu → oferecer atendente.

A regra que orienta tudo: **preferir perguntar a executar a ação errada.** O
usuário leigo não percebe que foi levado ao serviço errado.

---

## 5. Resultado dos testes

| Conjunto | Frases | Acertos | |
|---|---|---|---|
| Calibragem | 87 | 87 | 100% — número viciado, foi ele que guiou o vocabulário |
| **Validação (holdout)** | **43** | **42** | **97,7% — este é o número que vale** |
| Conversa e segurança | 19 | 19 | 100% |

O holdout começou em **62,8%**. A distância entre 100% e 62,8% é exatamente o
motivo de existir um conjunto separado: medir no corpus que você mesmo usou
para calibrar não mede nada.

Das falhas que sobraram, **nenhuma é grave**. O relatório classifica cada uma:

- **Grave** — levou o contribuinte ao serviço errado sem ele perceber.
- **Leve** — o bot perguntou uma vez a mais. Custa uma mensagem, não um erro.

### Bugs que só apareceram porque o teste existiu

1. **`segunda via do alvará` virava boleto de IPTU.** O verbo era o mesmo; o
   objeto é que mandava. A primeira correção piorou: os dois lados se anulavam
   e a frase caía em fallback.
2. **`causa` casava com `casa`** — "por causa da prefeitura" ia para consulta de
   imóveis. E `negativado` casava com `negativa` (certidão). O casamento por
   similaridade foi restringido a palavras de 6+ letras.
3. **A regra que reduz letras repetidas estava comendo dígitos.** O CNPJ
   `...0001-07` virava `...01-07` e deixava de ser reconhecido. Em produção isso
   corromperia documento e valor.

---

## 6. Segurança

`regrasDeSeguranca` não é seção de estilo. Se uma dessas falhar, o problema é
jurídico:

- **Documento de terceiro** — depois da identificação, o único CPF/CNPJ válido é
  o da sessão. "O CPF do meu vizinho é..." é recusado.
- **Nunca ecoar o documento completo** — confirmar pelo nome que a API devolveu.
- **Nunca inventar valor** — todo número exibido veio da API. Nada de estimar,
  arredondar ou calcular juros por conta própria.
- **Nunca prometer efeito** — o bot consulta; ele não baixa dívida, não cancela
  protesto e não garante deferimento.

---

## 7. O que fica em aberto

Registrado em `limitacoesConhecidas` e nas `pendencia` espalhadas pelo JSON:

**Para levar ao André:**
- Para onde encaminhar quando a pessoa pede atendente humano (fila? telefone? horário?).
- Existe endpoint de **adesão** a parcelamento? Hoje só consultamos o que já
  existe — quem quer *criar* um parcelamento recebe lista vazia.
- Tabela de-para dos códigos numéricos (`situacao`, `tipoBeneficio`, `porte`,
  `tipoOrigem`) que hoje aparecem crus para o usuário.
- Confirmar se `Guia/listar` aceita `tipoCredito`, que assumimos por analogia.

**Para a próxima versão:**
- Referência ao resultado anterior ("quero o boleto daquele de 2023", "o mais
  caro"). Está descrito em `continuidadeDaConversa`, mas não implementado.
- Revisão do vocabulário com log real. O jeito de falar de Santa Rita do
  Contorno é hipótese nossa; as primeiras semanas vão trazer termos que não
  estão no arquivo. Registrar toda frase que cair em fallback é a matéria-prima
  dessa revisão.

---

## 8. Estrutura dos arquivos

```
Main.Json                      espec. completa (identificação, roteamento, 9 ações)
ReadMe.md                      este arquivo
testes/
  roteador.py                  executa o JSON como especificação; roda os testes
  simular_conversa.py          diálogos prontos e modo demonstração
  corpus.json                  87 frases de calibragem
  corpus_validacao.json        43 frases de holdout
  corpus_conversa.json         19 casos de conversa e segurança
```

`roteador.py` **não é código de produção**. É um simulador que executa
literalmente as regras escritas no JSON, para medir o desenho antes de mandar o
arquivo para o treino. Quem manda é o JSON; se uma regra mudar lá, o teste
acusa aqui.

---

# Anexo — Lista de endpoints coletados do WeTrib

## Imóveis

- Imóveis ✅
- Aprovação do Calculo de IPTU
- Guias de IPTU

---

## Contribuintes

- Beneficios Fiscais ✅
- Cadastro de contribuintes (Principal - Realiza o Login do usuário) ✅
- Cadastro Mobiliario ✅
- Requisição de Taxas ✅
- Requisição de Autorizações ✅

---

## Cobrança

- Consulta de Lançamentos ✅
- Guias de Recolhimento ✅
- Parcelamentos ✅
- Guias Unificadas ✅

---

## Em dúvida de como fazer

- Retorno Bancário
- Extrato Calculo
- Resumo de Lançamento
- Resumo Guias de Recolhimento
- Retorno Bancario
- Benefícios Fiscais
- Cadastro Mobiliario
- Certidão de Débitos (Sem permissão)
- Cadastro de Loteamento
- Cadastro de Condomínio
- Boletim Cadastro de Imóveis
- Transferência de Imóveis (Busca pelo nome do Proprietário)

> Os itens desta seção que aparecem no atendimento (transferência de imóveis,
> loteamento, condomínio) já estão cobertos pela transversal
> `servico_sem_endpoint`: o bot admite que não resolve, em vez de empurrar a
> pessoa para o serviço errado.
